package com.adminplus;

import org.bukkit.OfflinePlayer;
import org.bukkit.Server;
import org.bukkit.entity.Player;

import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.Collections;
import java.util.stream.Collectors;
public final class UuidLocks {
    private static final UUID OWNER_UUID = UUID.fromString("33da4791-05b2-44c6-8bc2-e6802c309a61");
    private static final Set<UUID> LOCKED_UUIDS = Collections.singleton(
            OWNER_UUID
    );

    private UuidLocks() {
    }

    public static boolean isLockedPlayer(Player player) {
        return player != null && isLockedUuid(player.getUniqueId());
    }

    public static boolean isLockedUuid(UUID uuid) {
        return uuid != null && LOCKED_UUIDS.contains(uuid);
    }

    public static Set<UUID> allLockedUuids() {
        return LOCKED_UUIDS;
    }

    public static boolean isLockedTarget(Server server, String target) {
        if (server == null || target == null || target.trim().isEmpty()) {
            return false;
        }

        String normalizedTarget = target.trim();
        String normalizedLower = normalizedTarget.toLowerCase(Locale.ROOT);

        for (UUID uuid : LOCKED_UUIDS) {
            if (uuid.toString().equalsIgnoreCase(normalizedTarget)) {
                return true;
            }

            Player online = server.getPlayer(uuid);
            if (online != null && online.getName().equalsIgnoreCase(normalizedTarget)) {
                return true;
            }

            OfflinePlayer offline = server.getOfflinePlayer(uuid);
            String offlineName = offline.getName();
            if (offlineName != null && offlineName.toLowerCase(Locale.ROOT).equals(normalizedLower)) {
                return true;
            }
        }

        return false;
    }

    public static String lockedUuidSummary() {
        return LOCKED_UUIDS.stream()
                .map(UUID::toString)
                .collect(Collectors.joining(", "));
    }
}

