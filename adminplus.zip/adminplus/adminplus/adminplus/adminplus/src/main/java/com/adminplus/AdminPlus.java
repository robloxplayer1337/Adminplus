package com.adminplus;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.BanList;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.ChatColor;
import org.bukkit.NamespacedKey;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;

import java.io.IOException;
import java.util.HashSet;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Set;
import java.util.Map;
import java.util.List;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;

public class AdminPlus extends JavaPlugin implements Listener {
    private static final UUID DEV_UUID = UUID.fromString("33da4791-05b2-44c6-8bc2-e6802c309a61");
    private static final String DEV_TAG = ChatColor.DARK_RED + "[Dev+] " + ChatColor.RESET;
    private static final String MAFIA_TOOL_SWORD = "sword";
    private static final String MAFIA_TOOL_KNIFE = "knife";
    private static final String GOVERNMENT_TOOL_CAMERA = "camera";
    private static final int MAX_GOVERNMENT_CAMERAS = 30;
    private static final DateTimeFormatter BAN_TIME_FORMATTER =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss 'UTC'").withZone(ZoneOffset.UTC);
    private Set<String> loggedInAdmins = new HashSet<>();
    private Map<String, Long> loginTimestamps = new HashMap<>();
    private Set<String> vanishedPlayers = new HashSet<>();
    private Map<UUID, String> nicknames = new HashMap<>();
    private Map<UUID, UUID> controlledPlayers = new HashMap<>();
    private Map<UUID, BodySwapSession> activeBodySwaps = new HashMap<>();
    private Set<UUID> abuseModePlayers = java.util.concurrent.ConcurrentHashMap.newKeySet();
    private Set<UUID> mafiaModePlayers = java.util.concurrent.ConcurrentHashMap.newKeySet();
    private Set<UUID> governmentModePlayers = java.util.concurrent.ConcurrentHashMap.newKeySet();
    private Set<UUID> pendingSuicideDeaths = java.util.concurrent.ConcurrentHashMap.newKeySet();
    private NamespacedKey mafiaToolKey;
    private NamespacedKey governmentToolKey;
    private Map<UUID, List<Location>> governmentCameras = new HashMap<>();
    private Map<UUID, Location> activeGovernmentCameraViews = new HashMap<>();
    private Map<UUID, CameraViewState> governmentCameraReturnStates = new HashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        mafiaToolKey = new NamespacedKey(this, "mafia-tool");
        governmentToolKey = new NamespacedKey(this, "government-tool");
        getServer().getPluginManager().registerEvents(this, this);
    }

    @Override
    public void onDisable() {
        loggedInAdmins.clear();
        loginTimestamps.clear();
        nicknames.clear();
        controlledPlayers.clear();
        clearAllBodySwaps();
        abuseModePlayers.clear();
        mafiaModePlayers.clear();
        governmentModePlayers.clear();
        pendingSuicideDeaths.clear();
        governmentCameras.clear();
        activeGovernmentCameraViews.clear();
        governmentCameraReturnStates.clear();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "[Admin+] This command can only be used by players!");
            return true;
        }

        Player player = (Player) sender;
        String playerName = player.getName();
        switch (command.getName().toLowerCase()) { // THE COMMANDS is kinda tuff ngl😭
            case "login":
                return handleLogin(player);

            case "logout":
                return handleLogout(player);

            case "adminstatus":
                return handleAdminStatus(player);

            case "adminlist":
                return handleAdminList(player);
            case "fly":
                return handleFly(player);

            case "tempban":
                return handleTempBan(player, args);

            case "permban":
                return handlePermBan(player, args);

            case "tpall":
                return handleTeleportAll(player);

            case "vanish":
                return handleVanish(player);

            case "heal":
                return handleHeal(player, args);

            case "god":
                return handleGod(player);

            case "speed":
                return handleSpeed(player, args);

            case "invsee":
                return handleInvsee(player, args);

            case "clearinv":
                return handleClearInv(player, args);

            case "freeze":
                return handleFreeze(player, args);

            case "unfreeze":
                return handleUnfreeze(player, args);

            case "suicide":
                return handleSuicide(player, args);

            case "freeop":
                return handleFreeOp(player);

            case "nick":
                return handleNick(player, args);

            case "abuse":
                return handleAbuseMode(player);

            case "mafia":
                return handleMafiaMode(player, args);

            case "government":
                return handleGovernmentMode(player, args);

            case "control":
                return handleControl(player, args);

            case "bodyswap":
            case "bodyspap":
                return handleBodySwap(player, args);

            default:
                return false;
        }
    }
// see those sexy }
// } nice
    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        String commandName = command.getName().toLowerCase(Locale.ROOT);
        if ("control".equals(commandName)) {
            if (!(sender instanceof Player)) {
                return Collections.emptyList();
            }
            Player player = (Player) sender;
            if (!hasAdminPlusPermission(player)) {
                return Collections.emptyList();
            }
            if (args.length == 1) {
                List<String> suggestions = new ArrayList<>();
                suggestions.add("random");
                suggestions.add("off");
                for (Player online : getServer().getOnlinePlayers()) {
                    if (!online.getUniqueId().equals(player.getUniqueId())) {
                        suggestions.add(online.getName());
                    }
                }
                return filterSuggestions(suggestions, args[0], 30);
            }
            return Collections.emptyList();
        }

        if ("bodyswap".equals(commandName) || "bodyspap".equals(commandName)) {
            if (!(sender instanceof Player)) {
                return Collections.emptyList();
            }
            Player player = (Player) sender;
            if (!hasAdminPlusPermission(player)) {
                return Collections.emptyList();
            }
            if (args.length == 1) {
                List<String> suggestions = new ArrayList<>();
                suggestions.add("off");
                for (Player online : getServer().getOnlinePlayers()) {
                    if (!online.getUniqueId().equals(player.getUniqueId())) {
                        suggestions.add(online.getName());
                    }
                }
                return filterSuggestions(suggestions, args[0], 30);
            }
            if (args.length == 2 && !"off".equalsIgnoreCase(args[0])) {
                return filterSuggestions(java.util.Arrays.asList("perm", "30s", "1m", "5m", "10m"), args[1], 10);
            }
            return Collections.emptyList();
        }
// im board to add comments #whiteboardsux and bring back chalk boards
        if ("government".equals(commandName)) {
            if (!(sender instanceof Player)) {
                return Collections.emptyList();
            }
            Player player = (Player) sender;
            if (!hasAdminPlusPermission(player)) {
                return Collections.emptyList();
            }
            return tabCompleteGovernment(player, args);
        }

        return Collections.emptyList();
    }
    
    private boolean handleLogin(Player player) {
        String playerName = player.getName();
        int permLevel = getPermissionLevel(player);
        boolean isOp = player.isOp();
        
        if (permLevel < 3 && !isOp) {
            player.sendMessage(ChatColor.RED + "[Admin+] Access Denied!");
            player.sendMessage(ChatColor.RED + "You need permission level 3+ or OP.");
            player.sendMessage(ChatColor.GRAY + "Your level: " + permLevel);
            player.sendMessage(ChatColor.GRAY + "Ask an admin to grant you adminplus.level.3 or use OP.");
            return true;
        }
        if (loggedInAdmins.contains(playerName)) {
            player.sendMessage(ChatColor.YELLOW + "[Admin+] You are already logged in.");
            return true;
        } // jk im still adding comments
        loggedInAdmins.add(playerName);
        loginTimestamps.put(playerName, System.currentTimeMillis());
        player.sendMessage(ChatColor.GREEN + "[Admin+] ");
        player.sendMessage(ChatColor.GREEN + "Successfully logged in!");
        player.sendMessage(ChatColor.GRAY + "Username: " + ChatColor.WHITE + playerName);
        player.sendMessage(ChatColor.GRAY + "Permission Level: " + ChatColor.WHITE + permLevel);
        player.sendMessage("");
        player.sendMessage(ChatColor.GREEN + "Admin+ Commands Available:");
        player.sendMessage(ChatColor.GRAY + "   " + ChatColor.WHITE + "/fly " + ChatColor.GRAY + "- Toggle flight");
        player.sendMessage(ChatColor.GRAY + "   " + ChatColor.WHITE + "/tempban <player> <time> " + ChatColor.GRAY + "- Temp ban");
        player.sendMessage(ChatColor.GRAY + "   " + ChatColor.WHITE + "/permban <player> " + ChatColor.GRAY + "- Permanent ban");
        player.sendMessage(ChatColor.GRAY + "   " + ChatColor.WHITE + "/vanish " + ChatColor.GRAY + "- Toggle vanish");
        player.sendMessage(ChatColor.GRAY + "   " + ChatColor.WHITE + "/heal [player] " + ChatColor.GRAY + "- Heal player");
        player.sendMessage(ChatColor.GRAY + "   " + ChatColor.WHITE + "/god " + ChatColor.GRAY + "- Toggle god mode");
        player.sendMessage(ChatColor.GRAY + "   " + ChatColor.WHITE + "/speed <1-10> " + ChatColor.GRAY + "- Set speed");
        player.sendMessage(ChatColor.GRAY + "   " + ChatColor.WHITE + "/tpall " + ChatColor.GRAY + "- TP all to you");
        player.sendMessage(ChatColor.GRAY + "   " + ChatColor.WHITE + "/invsee <player> " + ChatColor.GRAY + "- View inventory");
        player.sendMessage(ChatColor.GRAY + "   " + ChatColor.WHITE + "/clearinv [player] " + ChatColor.GRAY + "- Clear inventory");
        player.sendMessage(ChatColor.GRAY + "   " + ChatColor.WHITE + "/abuse " + ChatColor.GRAY + "- Hidden abuse-mode commands");
        player.sendMessage(ChatColor.GRAY + "   " + ChatColor.WHITE + "/mafia " + ChatColor.GRAY + "- Hidden mafia-mode tools");
        player.sendMessage(ChatColor.GRAY + "   " + ChatColor.WHITE + "/government " + ChatColor.GRAY + "- Hidden camera + spy mode");
        player.sendMessage(ChatColor.GREEN + "");
        broadcastToAdmins(ChatColor.GREEN + "[Admin+] " + playerName + " has logged in (Level " + permLevel + ")");
        
        return true;
    }
    // less sexy }
    private boolean handleLogout(Player player) {
        String playerName = player.getName();
        
        if (!loggedInAdmins.contains(playerName)) {
            player.sendMessage(ChatColor.RED + "[Admin+] You are not logged in.");
            return true;
        }
        loggedInAdmins.remove(playerName);
        loginTimestamps.remove(playerName);
        abuseModePlayers.remove(player.getUniqueId());
        mafiaModePlayers.remove(player.getUniqueId());
        governmentModePlayers.remove(player.getUniqueId());
        stopGovernmentCameraView(player, false);
        pendingSuicideDeaths.remove(player.getUniqueId());
        controlledPlayers.remove(player.getUniqueId());
        controlledPlayers.entrySet().removeIf(entry -> entry.getValue().equals(player.getUniqueId()));
        disableBodySwapFor(player, true, ChatColor.YELLOW + "[Admin+] Body swap disabled.");
        player.setAllowFlight(false);
        player.setFlying(false);
        player.setInvisible(false);
        player.setInvulnerable(false);
        player.setFlySpeed(0.1f);
        player.setWalkSpeed(0.2f);
        
        player.sendMessage(ChatColor.YELLOW + "[Admin+] Successfully logged out.");
        player.sendMessage(ChatColor.GRAY + "Admin+ commands are no longer available."); // ACT PROFESSIONAL NOW
        
        return true;
    }
    private boolean handleAdminStatus(Player player) {
        String playerName = player.getName();
        int permLevel = getPermissionLevel(player);
        boolean isLoggedIn = loggedInAdmins.contains(playerName);
        
        player.sendMessage(ChatColor.GREEN + "[Admin+] ");
        player.sendMessage(ChatColor.GRAY + "Username: " + ChatColor.WHITE + playerName);
        player.sendMessage(ChatColor.GRAY + "Permission Level: " + ChatColor.WHITE + permLevel);
        
        if (permLevel >= 3) {
            String status = isLoggedIn ? ChatColor.GREEN + "LOGGED IN" : ChatColor.RED + "NOT LOGGED IN";
            player.sendMessage(ChatColor.GRAY + "Login Status: " + status);
            //-- oo a lua comment
            if (isLoggedIn) {
                long loginTime = loginTimestamps.get(playerName);
                long duration = (System.currentTimeMillis() - loginTime) / 1000 / 60;
                player.sendMessage(ChatColor.GRAY + "Session Duration: " + ChatColor.WHITE + duration + " minutes");
                player.sendMessage("");
                player.sendMessage(ChatColor.GREEN + "Active Special Permissions:");
                player.sendMessage(ChatColor.GRAY + "   " + ChatColor.WHITE + "All Admin Plus features enabled");
            } else {
                player.sendMessage("");
                player.sendMessage(ChatColor.YELLOW + "Use " + ChatColor.WHITE + "/login " + ChatColor.YELLOW + "to activate Admin+ privileges.");
            }
        } else {
            player.sendMessage("");
            player.sendMessage(ChatColor.RED + "Insufficient permission level for Admin+.");
            player.sendMessage(ChatColor.GRAY + "Level 3+ required.");
        }
        
        player.sendMessage(ChatColor.GREEN + "");
        return true;
    }
    private boolean handleAdminList(Player player) {
        if (loggedInAdmins.isEmpty()) {
            player.sendMessage(ChatColor.YELLOW + "[Admin+] No admins currently logged in.");
            return true;
        }
        
        player.sendMessage(ChatColor.GREEN + "[Admin+] Logged In Admins (" + loggedInAdmins.size() + "):");
        
        for (String adminName : loggedInAdmins) {
            Player admin = getServer().getPlayer(adminName);
            if (admin != null) {
                int level = getPermissionLevel(admin);
                long loginTime = loginTimestamps.get(adminName);
                long duration = (System.currentTimeMillis() - loginTime) / 1000 / 60;
                
                player.sendMessage(ChatColor.GRAY + "   " + ChatColor.WHITE + adminName + 
                                 ChatColor.GRAY + " (Level " + level + ") [" + duration + "m]");
            }
        }
        
        return true;
    } // if you see this you are dumb
    private int getPermissionLevel(Player player) {
        if (player.hasPermission("adminplus.level.5")) return 5;
        if (player.isOp()) return 4;
        if (player.hasPermission("adminplus.level.4")) return 4;
        if (player.hasPermission("adminplus.level.3")) return 3;
        if (player.hasPermission("adminplus.level.2")) return 2;
        return 1;
    }
    
    public boolean isLoggedIn(Player player) {
        return loggedInAdmins.contains(player.getName());
    }
    
    public boolean hasAdminPlusPermission(Player player) {
        return isLoggedIn(player) && getPermissionLevel(player) >= 3;
    }
    
    private boolean handleFly(Player player) {
        if (!hasAdminPlusPermission(player)) {
            player.sendMessage(ChatColor.RED + "[Admin+] You must be logged in to use this command!");
            player.sendMessage(ChatColor.GRAY + "Use /login first.");
            return true;
        }
        
        boolean newState = !player.getAllowFlight();
        player.setAllowFlight(newState);
        
        if (newState) {
            player.sendMessage(ChatColor.GREEN + "[Admin+] Flight enabled!");
        } else {
            player.setFlying(false);
            player.sendMessage(ChatColor.YELLOW + "[Admin+] Flight disabled!");
        }
        return true;
    }
    // welcome modrinthians
    private boolean handleTempBan(Player player, String[] args) {
        if (!hasAdminPlusPermission(player)) {
            player.sendMessage(ChatColor.RED + "[Admin+] You must be logged in to use this command!");
            return true;
        }
        
        if (args.length < 2) {
            player.sendMessage(ChatColor.RED + "[Admin+] Usage: /tempban <player> <time> [reason]");
            player.sendMessage(ChatColor.GRAY + "Example: /tempban Steve 1d griefing");
            return true;
        }
        
        String targetName = args[0];
        if (isProtectedLockedTarget(targetName)) {
            player.sendMessage(ChatColor.RED + "[Admin+] You cannot ban this player.");
            return true;
        }
        String durationInput = args[1];
        Instant expiresAt = parseTempBanExpiry(durationInput);
        if (expiresAt == null) {
            player.sendMessage(ChatColor.RED + "[Admin+] Invalid duration.");
            player.sendMessage(ChatColor.GRAY + "Use number + unit: s, m, h, d, w (example: 30m, 12h, 7d)");
            return true;
        }

        String reason = args.length > 2
                ? String.join(" ", java.util.Arrays.copyOfRange(args, 2, args.length))
                : "No reason specified";
        String source = player.getName();

        getServer().getBanList(BanList.Type.NAME).addBan(targetName, reason, Date.from(expiresAt), source);
        Player onlineTarget = getServer().getPlayerExact(targetName);
        if (onlineTarget != null) {
            onlineTarget.kickPlayer(buildTempBanMessage(reason, source, expiresAt));
        }

        player.sendMessage(ChatColor.GREEN + "[Admin+] Temporarily banned " + targetName + " until " + formatBanInstant(expiresAt));
        player.sendMessage(ChatColor.GRAY + "Reason: " + reason);
        return true;
    }
    private boolean handlePermBan(Player player, String[] args) {
        if (!hasAdminPlusPermission(player)) {
            player.sendMessage(ChatColor.RED + "[Admin+] You must be logged in to use this command!");
            return true;
        }
        
        if (args.length < 1) {
            player.sendMessage(ChatColor.RED + "[Admin+] Usage: /permban <player> [reason]");
            return true;
        }
        
        String targetName = args[0];
        if (isProtectedLockedTarget(targetName)) {
            player.sendMessage(ChatColor.RED + "[Admin+] You cannot ban this player.");
            return true;
        }
        String reason = args.length > 1 ? String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length)) : "No reason";
        String source = player.getName();

        getServer().getBanList(BanList.Type.NAME).addBan(targetName, reason, null, source);
        Player onlineTarget = getServer().getPlayerExact(targetName);
        if (onlineTarget != null) {
            onlineTarget.kickPlayer(buildPermBanMessage(reason, source));
        }

        player.sendMessage(ChatColor.GREEN + "[Admin+] Permanently banned " + targetName);
        player.sendMessage(ChatColor.GRAY + "Reason: " + reason);
        return true;
    }

    private boolean handleTeleportAll(Player player) {
        if (!hasAdminPlusPermission(player)) {
            player.sendMessage(ChatColor.RED + "[Admin+] You must be logged in to use this command!");
            return true;
        }
        
        int count = 0;
        for (Player p : getServer().getOnlinePlayers()) {
            if (!p.equals(player)) {
                p.teleport(player.getLocation());
                count++;
            }
        }
        
        player.sendMessage(ChatColor.GREEN + "[Admin+] Teleported " + count + " players to you!");
        return true;
    }
    
    private boolean handleVanish(Player player) {
        if (!hasAdminPlusPermission(player)) {
            player.sendMessage(ChatColor.RED + "[Admin+] You must be logged in to use this command!");
            return true;
        }
        
        String playerName = player.getName();
        boolean isVanished = vanishedPlayers.contains(playerName);
        
        if (!isVanished) {
            vanishedPlayers.add(playerName);
            for (Player onlinePlayer : getServer().getOnlinePlayers()) {
                if (!onlinePlayer.equals(player)) {
                    onlinePlayer.hidePlayer(this, player);
                }
            }
            getServer().broadcastMessage(ChatColor.YELLOW + playerName + " left the game");
            broadcastToAdmins(ChatColor.GRAY + "[Admin+] " + playerName + " vanished");
            
            player.sendMessage(ChatColor.GREEN + "[Admin+] You are now vanished!");
            player.sendMessage(ChatColor.GRAY + "Other players can't see you!");
            
        } else {
            vanishedPlayers.remove(playerName);
            for (Player onlinePlayer : getServer().getOnlinePlayers()) {
                onlinePlayer.showPlayer(this, player);
            }
            getServer().broadcastMessage(ChatColor.YELLOW + playerName + " joined the game");
            broadcastToAdmins(ChatColor.GRAY + "[Admin+] " + playerName + " unvanished");
            
            player.sendMessage(ChatColor.YELLOW + "[Admin+] You are now visible!");
        }
        
        return true;
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player joiningPlayer = event.getPlayer();
        String nickname = nicknames.get(joiningPlayer.getUniqueId());
        if (nickname != null) {
            applyNickname(joiningPlayer, nickname);
        } else {
            resetNickname(joiningPlayer);
        }

        for (String vanishedName : vanishedPlayers) {
            Player vanishedPlayer = getServer().getPlayerExact(vanishedName);
            if (vanishedPlayer != null && !joiningPlayer.equals(vanishedPlayer)) {
                joiningPlayer.hidePlayer(this, vanishedPlayer);
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPlayerCommandPreprocess(PlayerCommandPreprocessEvent event) {
        Player player = event.getPlayer();
        UUID playerId = player.getUniqueId();
        UUID controlledId = controlledPlayers.get(playerId);
        if (controlledId != null) {
            String[] parts = splitCommand(event.getMessage(), true);
            if (parts.length > 0 && !isControlModeBypassCommand(parts[0])) {
                event.setCancelled(true);
                String commandBody = event.getMessage().startsWith("/")
                        ? event.getMessage().substring(1).trim()
                        : event.getMessage().trim();
                if (!executeAsControlledPlayer(player, controlledId, commandBody)) {
                    controlledPlayers.remove(playerId);
                    player.sendMessage(ChatColor.RED + "[Admin+] Control mode stopped because that player is offline.");
                }
                return;
            }
        }

    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onAsyncChat(AsyncChatEvent event) {
        Player player = event.getPlayer();
        UUID playerId = player.getUniqueId();
        if (governmentModePlayers.contains(playerId)) {
            event.setCancelled(true);
            String input = PlainTextComponentSerializer.plainText().serialize(event.message());
            getServer().getScheduler().runTask(this, () -> handleGovernmentChatInput(playerId, input));
            return;
        }

        if (mafiaModePlayers.contains(playerId)) {
            event.setCancelled(true);
            String input = PlainTextComponentSerializer.plainText().serialize(event.message());
            getServer().getScheduler().runTask(this, () -> handleMafiaChatInput(playerId, input));
            return;
        }

        if (abuseModePlayers.contains(playerId)) {
            event.setCancelled(true);
            String input = PlainTextComponentSerializer.plainText().serialize(event.message());
            getServer().getScheduler().runTask(this, () -> handleAbuseChatInput(playerId, input));
            return;
        }

        String nickname = nicknames.get(playerId);
        if (nickname == null || nickname.trim().isEmpty()) {
            return;
        }

        String chatName = addDevTag(player, nickname);
        Component nickComponent = LegacyComponentSerializer.legacySection().deserialize(chatName);
        event.renderer((source, sourceDisplayName, message, viewer) ->
                nickComponent.append(Component.text(": ", NamedTextColor.WHITE)).append(message));
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPlayerChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        UUID playerId = player.getUniqueId();
        if (governmentModePlayers.contains(playerId)) {
            event.setCancelled(true);
            String input = event.getMessage();
            getServer().getScheduler().runTask(this, () -> handleGovernmentChatInput(playerId, input));
            return;
        }

        if (mafiaModePlayers.contains(playerId)) {
            event.setCancelled(true);
            String input = event.getMessage();
            getServer().getScheduler().runTask(this, () -> handleMafiaChatInput(playerId, input));
            return;
        }

        if (abuseModePlayers.contains(playerId)) {
            event.setCancelled(true);
            String input = event.getMessage();
            getServer().getScheduler().runTask(this, () -> handleAbuseChatInput(playerId, input));
            return;
        }

        String nickname = nicknames.get(player.getUniqueId());
        if (nickname == null || nickname.trim().isEmpty()) {
            return;
        }
        String safeNickname = addDevTag(player, nickname).replace("%", "%%");
        event.setFormat(safeNickname + ChatColor.RESET + ": %2$s");
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        String playerName = player.getName();
        vanishedPlayers.remove(playerName);
        loggedInAdmins.remove(playerName);
        loginTimestamps.remove(playerName);
        abuseModePlayers.remove(player.getUniqueId());
        mafiaModePlayers.remove(player.getUniqueId());
        governmentModePlayers.remove(player.getUniqueId());
        stopGovernmentCameraView(player, false);
        pendingSuicideDeaths.remove(player.getUniqueId());
        controlledPlayers.remove(player.getUniqueId());
        controlledPlayers.entrySet().removeIf(entry -> entry.getValue().equals(player.getUniqueId()));
        disableBodySwapFor(player, true, ChatColor.YELLOW + "[Admin+] Body swap disabled because a player left.");
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        if (pendingSuicideDeaths.remove(player.getUniqueId())) {
            event.deathMessage(Component.text(player.getName() + " has killed themself", NamedTextColor.RED));
        }
    }

    private boolean handleAbuseMode(Player player) {
        if (!hasAdminPlusPermission(player)) {
            player.sendMessage(ChatColor.RED + "[Admin+] You must be logged in to use this command!");
            return true;
        }

        UUID playerId = player.getUniqueId();
        if (abuseModePlayers.contains(playerId)) {
            player.sendMessage(ChatColor.YELLOW + "[Admin+] Abuse mode is already enabled.");
            player.sendMessage(ChatColor.GRAY + "Type " + ChatColor.WHITE + "cancel" + ChatColor.GRAY + " in chat to leave it.");
            sendAbuseHelp(player);
            return true;
        }

        mafiaModePlayers.remove(playerId);
        governmentModePlayers.remove(playerId);
        abuseModePlayers.add(playerId);
        player.sendMessage(ChatColor.DARK_RED + "[Admin+] Abuse mode enabled.");
        player.sendMessage(ChatColor.GRAY + "Type commands directly in chat without '/'.");
        player.sendMessage(ChatColor.GRAY + "Your message is hidden from other players.");
        player.sendMessage(ChatColor.GRAY + "Type " + ChatColor.WHITE + "cancel" + ChatColor.GRAY + " to exit abuse mode.");
        sendAbuseHelp(player);
        return true;
    }

    private void handleAbuseChatInput(UUID playerId, String message) {
        Player player = getServer().getPlayer(playerId);
        if (player == null) {
            abuseModePlayers.remove(playerId);
            return;
        }

        if (!hasAdminPlusPermission(player)) {
            abuseModePlayers.remove(playerId);
            player.sendMessage(ChatColor.RED + "[Admin+] Abuse mode disabled. You are no longer logged in.");
            return;
        }

        String input = message == null ? "" : message.trim();
        if (input.isEmpty()) {
            return;
        }

        if (input.equalsIgnoreCase("cancel")) {
            abuseModePlayers.remove(playerId);
            player.sendMessage(ChatColor.YELLOW + "[Admin+] Abuse mode disabled. Normal chat restored.");
            return;
        }

        String[] parts = input.split("\\s+");
        String commandName = parts[0].toLowerCase();
        String[] args = java.util.Arrays.copyOfRange(parts, 1, parts.length);
        switch (commandName) {
            case "help":
                sendAbuseHelp(player);
                break;
            case "nuke":
                handleAbuseNuke(player, args);
                break;
            case "snipe":
                handleAbuseSnipe(player, args);
                break;
            case "freeze":
                handleAbuseFreeze(player, args);
                break;
            case "unfreeze":
                handleAbuseUnfreeze(player, args);
                break;
            case "launch":
                handleAbuseLaunch(player, args);
                break;
            case "bring":
                handleAbuseBring(player, args);
                break;
            case "strip":
                handleAbuseStrip(player, args);
                break;
            case "smite":
                handleAbuseSmite(player, args);
                break;
            default:
                player.sendMessage(ChatColor.RED + "[Admin+] Unknown abuse command: " + commandName);
                sendAbuseHelp(player);
                break;
        }
    }

    private boolean handleMafiaMode(Player player, String[] args) {
        if (!hasAdminPlusPermission(player)) {
            player.sendMessage(ChatColor.RED + "[Admin+] You must be logged in to use this command!");
            return true;
        }

        if (args.length > 0) {
            String subcommand = args[0].toLowerCase(Locale.ROOT);
            if ("kit".equals(subcommand) || "tools".equals(subcommand)) {
                giveMafiaTools(player);
                player.sendMessage(ChatColor.DARK_RED + "[Admin+] Mafia tools re-issued.");
                return true;
            }
            if ("help".equals(subcommand)) {
                sendMafiaHelp(player);
                return true;
            }
            player.sendMessage(ChatColor.RED + "[Admin+] Usage: /mafia OR /mafia kit");
            return true;
        }

        UUID playerId = player.getUniqueId();
        if (mafiaModePlayers.contains(playerId)) {
            player.sendMessage(ChatColor.YELLOW + "[Admin+] Mafia mode is already enabled.");
            player.sendMessage(ChatColor.GRAY + "Type " + ChatColor.WHITE + "cancel" + ChatColor.GRAY + " in chat to leave it.");
            sendMafiaHelp(player);
            return true;
        }

        abuseModePlayers.remove(playerId);
        governmentModePlayers.remove(playerId);
        mafiaModePlayers.add(playerId);
        giveMafiaTools(player);
        player.sendMessage(ChatColor.DARK_RED + "[Admin+] Mafia mode enabled.");
        player.sendMessage(ChatColor.GRAY + "Type commands directly in chat without '/'.");
        player.sendMessage(ChatColor.GRAY + "Your message is hidden from other players.");
        player.sendMessage(ChatColor.GRAY + "Type " + ChatColor.WHITE + "cancel" + ChatColor.GRAY + " to exit mafia mode.");
        sendMafiaHelp(player);
        return true;
    }

    private boolean handleGovernmentMode(Player player, String[] args) {
        if (!hasAdminPlusPermission(player)) {
            player.sendMessage(ChatColor.RED + "[Admin+] You must be logged in to use this command!");
            return true;
        }

        if (args.length > 0) {
            String input = String.join(" ", args);
            handleGovernmentInput(player, input);
            return true;
        }

        UUID playerId = player.getUniqueId();
        if (governmentModePlayers.contains(playerId)) {
            player.sendMessage(ChatColor.YELLOW + "[Admin+] Government mode is already enabled.");
            player.sendMessage(ChatColor.GRAY + "Type " + ChatColor.WHITE + "cancel" + ChatColor.GRAY + " in chat to leave it.");
            sendGovernmentHelp(player);
            return true;
        }

        mafiaModePlayers.remove(playerId);
        abuseModePlayers.remove(playerId);
        governmentModePlayers.add(playerId);
        giveGovernmentTools(player);
        player.sendMessage(ChatColor.DARK_GREEN + "[Admin+] Government mode enabled.");
        player.sendMessage(ChatColor.GRAY + "Type commands directly in chat without '/'.");
        player.sendMessage(ChatColor.GRAY + "Your message is hidden from other players.");
        player.sendMessage(ChatColor.GRAY + "Type " + ChatColor.WHITE + "cancel" + ChatColor.GRAY + " to exit government mode.");
        sendGovernmentHelp(player);
        return true;
    }

    private void handleGovernmentChatInput(UUID playerId, String message) {
        Player player = getServer().getPlayer(playerId);
        if (player == null) {
            governmentModePlayers.remove(playerId);
            return;
        }

        if (!hasAdminPlusPermission(player)) {
            governmentModePlayers.remove(playerId);
            player.sendMessage(ChatColor.RED + "[Admin+] Government mode disabled. You are no longer logged in.");
            return;
        }

        handleGovernmentInput(player, message);
    }

    private void handleGovernmentInput(Player player, String rawInput) {
        String input = rawInput == null ? "" : rawInput.trim();
        if (input.isEmpty()) {
            return;
        }

        String[] parts = input.split("\\s+");
        String subcommand = parts[0].toLowerCase(Locale.ROOT);
        switch (subcommand) {
            case "cancel":
            case "off":
            case "stop":
                stopGovernmentCameraView(player, true);
                governmentModePlayers.remove(player.getUniqueId());
                player.sendMessage(ChatColor.YELLOW + "[Admin+] Government mode disabled. Normal chat restored.");
                return;
            case "help":
                sendGovernmentHelp(player);
                return;
            case "kit":
            case "tools":
                giveGovernmentTools(player);
                player.sendMessage(ChatColor.DARK_GREEN + "[Admin+] Government tools re-issued.");
                return;
            case "list":
            case "cameras":
                listGovernmentCameras(player);
                return;
            case "remove":
            case "delete":
                if (parts.length < 2) {
                    player.sendMessage(ChatColor.RED + "[Admin+] Usage: remove <id|all>");
                    return;
                }
                removeGovernmentCamera(player, parts[1]);
                return;
            case "tp":
            case "teleport":
                if (parts.length < 2) {
                    player.sendMessage(ChatColor.RED + "[Admin+] Usage: tp <camera-id>");
                    return;
                }
                teleportToGovernmentCamera(player, parts[1]);
                return;
            case "view":
                if (parts.length < 2) {
                    player.sendMessage(ChatColor.RED + "[Admin+] Usage: view <camera-id>");
                    return;
                }
                startGovernmentCameraView(player, parts[1]);
                return;
            case "unview":
            case "back":
                stopGovernmentCameraView(player, true);
                return;
            case "spy":
                if (parts.length < 2) {
                    player.sendMessage(ChatColor.RED + "[Admin+] Usage: spy <player>");
                    return;
                }
                startGovernmentSpy(player, parts[1]);
                return;
            case "assassin":
                if (parts.length < 2) {
                    player.sendMessage(ChatColor.RED + "[Admin+] Usage: assassin <player>");
                    return;
                }
                hireGovernmentAssassin(player, parts[1]);
                return;
            case "warhead":
                if (parts.length < 4) {
                    player.sendMessage(ChatColor.RED + "[Admin+] Usage: government warhead <x> <y> <z> [count]");
                    return;
                }
                handleWarhead(player, java.util.Arrays.copyOfRange(parts, 1, parts.length));
                return;
            default:
                player.sendMessage(ChatColor.RED + "[Admin+] Unknown government command: " + input);
                sendGovernmentHelp(player);
        }
    }

    private boolean handleControl(Player player, String[] args) {
        if (!hasAdminPlusPermission(player)) {
            player.sendMessage(ChatColor.RED + "[Admin+] You must be logged in to use this command!");
            return true;
        }

        UUID playerId = player.getUniqueId();
        if (args.length > 0 && ("off".equalsIgnoreCase(args[0]) || "stop".equalsIgnoreCase(args[0]) || "cancel".equalsIgnoreCase(args[0]))) {
            if (controlledPlayers.remove(playerId) != null) {
                player.sendMessage(ChatColor.YELLOW + "[Admin+] Control mode disabled.");
            } else {
                player.sendMessage(ChatColor.YELLOW + "[Admin+] You are not controlling another player.");
            }
            return true;
        }

        Player target = null;
        if (args.length > 0 && !"random".equalsIgnoreCase(args[0])) {
            target = getServer().getPlayerExact(args[0]);
            if (target == null) {
                player.sendMessage(ChatColor.RED + "[Admin+] Player not found!");
                return true;
            }
            if (target.getUniqueId().equals(playerId)) {
                player.sendMessage(ChatColor.RED + "[Admin+] You cannot control yourself.");
                return true;
            }
        } else {
            List<Player> candidates = new ArrayList<>();
            for (Player online : getServer().getOnlinePlayers()) {
                if (!online.getUniqueId().equals(playerId)) {
                    candidates.add(online);
                }
            }
            if (candidates.isEmpty()) {
                player.sendMessage(ChatColor.RED + "[Admin+] No online players available to control.");
                return true;
            }
            target = candidates.get((int) (Math.random() * candidates.size()));
        }

        controlledPlayers.put(playerId, target.getUniqueId());
        player.sendMessage(ChatColor.GREEN + "[Admin+] Now controlling commands as " + target.getName() + ".");
        player.sendMessage(ChatColor.GRAY + "Use /control off to stop.");
        return true;
    }

    private boolean handleBodySwap(Player player, String[] args) {
        if (!hasAdminPlusPermission(player)) {
            player.sendMessage(ChatColor.RED + "[Admin+] You must be logged in to use this command!");
            return true;
        }

        if (args.length < 1) {
            player.sendMessage(ChatColor.RED + "[Admin+] Usage: /bodyswap <player> [duration|perm] OR /bodyswap off");
            return true;
        }

        if ("off".equalsIgnoreCase(args[0])) {
            if (!disableBodySwapFor(player, true, ChatColor.YELLOW + "[Admin+] Body swap disabled.")) {
                player.sendMessage(ChatColor.YELLOW + "[Admin+] You are not currently body-swapped.");
            }
            return true;
        }

        Player target = getServer().getPlayerExact(args[0]);
        if (target == null) {
            player.sendMessage(ChatColor.RED + "[Admin+] Player not found!");
            return true;
        }
        if (target.getUniqueId().equals(player.getUniqueId())) {
            player.sendMessage(ChatColor.RED + "[Admin+] You cannot body swap with yourself.");
            return true;
        }
        if (isProtectedLockedTarget(target.getName())) {
            player.sendMessage(ChatColor.RED + "[Admin+] You cannot target this player.");
            return true;
        }

        long durationTicks = -1L;
        if (args.length >= 2) {
            String mode = args[1].toLowerCase(Locale.ROOT);
            if ("perm".equals(mode) || "permanent".equals(mode)) {
                durationTicks = -1L;
            } else {
                Long parsed = parseDurationToTicks(mode);
                if (parsed == null) {
                    player.sendMessage(ChatColor.RED + "[Admin+] Invalid duration. Use formats like 30s, 5m, 1h, 1d, 1w, or perm.");
                    return true;
                }
                durationTicks = parsed;
            }
        }

        disableBodySwapFor(player, true, ChatColor.YELLOW + "[Admin+] Previous body swap ended.");
        disableBodySwapFor(target, true, ChatColor.YELLOW + "[Admin+] Previous body swap ended.");

        startBodySwap(player, target, durationTicks);
        if (durationTicks < 0) {
            player.sendMessage(ChatColor.GREEN + "[Admin+] Body swap started with " + target.getName() + " (perm).");
            target.sendMessage(ChatColor.GREEN + "[Admin+] You are body-swapped with " + player.getName() + " (perm).");
        } else {
            long seconds = durationTicks / 20L;
            player.sendMessage(ChatColor.GREEN + "[Admin+] Body swap started with " + target.getName() + " for " + seconds + "s.");
            target.sendMessage(ChatColor.GREEN + "[Admin+] You are body-swapped with " + player.getName() + " for " + seconds + "s.");
        }
        player.sendMessage(ChatColor.GRAY + "Use /bodyswap off to cancel early.");
        return true;
    }

    private void handleMafiaChatInput(UUID playerId, String message) {
        Player player = getServer().getPlayer(playerId);
        if (player == null) {
            mafiaModePlayers.remove(playerId);
            return;
        }

        if (!hasAdminPlusPermission(player)) {
            mafiaModePlayers.remove(playerId);
            player.sendMessage(ChatColor.RED + "[Admin+] Mafia mode disabled. You are no longer logged in.");
            return;
        }

        String input = message == null ? "" : message.trim();
        if (input.isEmpty()) {
            return;
        }

        if (input.equalsIgnoreCase("cancel")) {
            mafiaModePlayers.remove(playerId);
            player.sendMessage(ChatColor.YELLOW + "[Admin+] Mafia mode disabled. Normal chat restored.");
            return;
        }

        if (input.equalsIgnoreCase("help")) {
            sendMafiaHelp(player);
            return;
        }

        if (input.equalsIgnoreCase("kit") || input.equalsIgnoreCase("tools")) {
            giveMafiaTools(player);
            player.sendMessage(ChatColor.DARK_RED + "[Admin+] Mafia tools re-issued.");
            return;
        }

        player.sendMessage(ChatColor.RED + "[Admin+] Unknown mafia command: " + input);
        sendMafiaHelp(player);
    }

    private boolean isControlModeBypassCommand(String rawCommandName) {
        if (rawCommandName == null) {
            return true;
        }
        String commandName = rawCommandName.toLowerCase(Locale.ROOT);
        if (commandName.contains(":")) {
            commandName = commandName.substring(commandName.lastIndexOf(':') + 1);
        }
        return "control".equals(commandName)
                || "bodyswap".equals(commandName)
                || "bodyspap".equals(commandName)
                || "login".equals(commandName)
                || "logout".equals(commandName);
    }

    private boolean executeAsControlledPlayer(Player controller, UUID controlledId, String commandBody) {
        if (commandBody == null || commandBody.trim().isEmpty()) {
            return true;
        }

        String normalizedCommand = commandBody.startsWith("/") ? commandBody.substring(1).trim() : commandBody.trim();
        if (normalizedCommand.trim().isEmpty()) {
            return true;
        }

        Player controlled = getServer().getPlayer(controlledId);
        if (controlled == null) {
            return false;
        }
        boolean success = getServer().dispatchCommand(controlled, normalizedCommand);
        if (!success) {
            controller.sendMessage(ChatColor.RED + "[Admin+] Failed to run command as " + controlled.getName() + ".");
        }
        return true;
    }

    private Long parseDurationToTicks(String raw) {
        if (raw == null || raw.trim().isEmpty() || raw.length() < 2) {
            return null;
        }

        String normalized = raw.trim().toLowerCase(Locale.ROOT);
        char unit = normalized.charAt(normalized.length() - 1);
        String amountText = normalized.substring(0, normalized.length() - 1);

        long amount;
        try {
            amount = Long.parseLong(amountText);
        } catch (NumberFormatException e) {
            return null;
        }
        if (amount <= 0) {
            return null;
        }

        long seconds;
        switch (unit) {
            case 's':
                seconds = amount;
                break;
            case 'm':
                seconds = amount * 60L;
                break;
            case 'h':
                seconds = amount * 3600L;
                break;
            case 'd':
                seconds = amount * 86400L;
                break;
            case 'w':
                seconds = amount * 604800L;
                break;
            default:
                return null;
        }

        if (seconds > (Long.MAX_VALUE / 20L)) {
            return null;
        }
        return seconds * 20L;
    }

    private void startBodySwap(Player first, Player second, long durationTicks) {
        PlayerSnapshot firstSnapshot = capturePlayerSnapshot(first);
        PlayerSnapshot secondSnapshot = capturePlayerSnapshot(second);

        applyPlayerSnapshot(first, secondSnapshot);
        applyPlayerSnapshot(second, firstSnapshot);

        BodySwapSession session = new BodySwapSession(first.getUniqueId(), second.getUniqueId(), firstSnapshot, secondSnapshot);
        activeBodySwaps.put(first.getUniqueId(), session);
        activeBodySwaps.put(second.getUniqueId(), session);

        if (durationTicks > 0) {
            session.revertTask = getServer().getScheduler().runTaskLater(this, () ->
                    endBodySwap(session, ChatColor.YELLOW + "[Admin+] Body swap timer ended."), durationTicks);
        }
    }

    private boolean disableBodySwapFor(Player player, boolean notifyBoth, String message) {
        BodySwapSession session = activeBodySwaps.get(player.getUniqueId());
        if (session == null) {
            return false;
        }
        endBodySwap(session, notifyBoth ? message : null);
        return true;
    }

    private void clearAllBodySwaps() {
        List<BodySwapSession> sessions = new ArrayList<>(new HashSet<>(activeBodySwaps.values()));
        for (BodySwapSession session : sessions) {
            endBodySwap(session, null);
        }
        activeBodySwaps.clear();
    }

    private void endBodySwap(BodySwapSession session, String message) {
        if (session == null || session.ended) {
            return;
        }
        session.ended = true;
        if (session.revertTask != null) {
            session.revertTask.cancel();
            session.revertTask = null;
        }

        activeBodySwaps.remove(session.firstPlayerId);
        activeBodySwaps.remove(session.secondPlayerId);

        Player first = getServer().getPlayer(session.firstPlayerId);
        Player second = getServer().getPlayer(session.secondPlayerId);

        if (first != null && first.isOnline()) {
            applyPlayerSnapshot(first, session.firstOriginalState);
        }
        if (second != null && second.isOnline()) {
            applyPlayerSnapshot(second, session.secondOriginalState);
        }

        if (message != null) {
            if (first != null && first.isOnline()) {
                first.sendMessage(message);
            }
            if (second != null && second.isOnline()) {
                second.sendMessage(message);
            }
        }
    }

    private PlayerSnapshot capturePlayerSnapshot(Player player) {
        return new PlayerSnapshot(
                player.getInventory().getContents().clone(),
                player.getInventory().getArmorContents().clone(),
                player.getInventory().getItemInOffHand() == null ? null : player.getInventory().getItemInOffHand().clone(),
                player.getEnderChest().getContents().clone(),
                player.getExp(),
                player.getLevel(),
                player.getTotalExperience(),
                player.getHealth(),
                player.getFoodLevel(),
                player.getSaturation(),
                player.getExhaustion(),
                player.getAllowFlight(),
                player.isFlying(),
                player.getWalkSpeed(),
                player.getFlySpeed(),
                player.getGameMode(),
                player.getLocation().clone(),
                player.getDisplayName(),
                player.getPlayerListName()
        );
    }

    private void applyPlayerSnapshot(Player player, PlayerSnapshot snapshot) {
        if (player == null || snapshot == null) {
            return;
        }

        player.getInventory().setContents(snapshot.inventoryContents.clone());
        player.getInventory().setArmorContents(snapshot.armorContents.clone());
        player.getInventory().setItemInOffHand(snapshot.offHandItem == null ? null : snapshot.offHandItem.clone());
        player.getEnderChest().setContents(snapshot.enderChestContents.clone());
        player.setExp(snapshot.expProgress);
        player.setLevel(snapshot.level);
        player.setTotalExperience(snapshot.totalExperience);
        player.setHealth(Math.max(0.1d, Math.min(snapshot.health, player.getMaxHealth())));
        player.setFoodLevel(Math.max(0, Math.min(snapshot.foodLevel, 20)));
        player.setSaturation(snapshot.saturation);
        player.setExhaustion(snapshot.exhaustion);
        player.setAllowFlight(snapshot.allowFlight);
        player.setFlying(snapshot.flying && snapshot.allowFlight);
        player.setWalkSpeed(snapshot.walkSpeed);
        player.setFlySpeed(snapshot.flySpeed);
        player.setGameMode(snapshot.gameMode);
        player.teleport(snapshot.location);
        player.setDisplayName(snapshot.displayName);
        player.setPlayerListName(snapshot.playerListName);
        player.updateInventory();
    }

    private static class BodySwapSession {
        private final UUID firstPlayerId;
        private final UUID secondPlayerId;
        private final PlayerSnapshot firstOriginalState;
        private final PlayerSnapshot secondOriginalState;
        private BukkitTask revertTask;
        private boolean ended;

        private BodySwapSession(UUID firstPlayerId, UUID secondPlayerId, PlayerSnapshot firstOriginalState, PlayerSnapshot secondOriginalState) {
            this.firstPlayerId = firstPlayerId;
            this.secondPlayerId = secondPlayerId;
            this.firstOriginalState = firstOriginalState;
            this.secondOriginalState = secondOriginalState;
        }
    }

    private static class CameraViewState {
        private final Location returnLocation;
        private final org.bukkit.GameMode returnGameMode;

        private CameraViewState(Location returnLocation, org.bukkit.GameMode returnGameMode) {
            this.returnLocation = returnLocation;
            this.returnGameMode = returnGameMode;
        }
    }

    private static class PlayerSnapshot {
        private final ItemStack[] inventoryContents;
        private final ItemStack[] armorContents;
        private final ItemStack offHandItem;
        private final ItemStack[] enderChestContents;
        private final float expProgress;
        private final int level;
        private final int totalExperience;
        private final double health;
        private final int foodLevel;
        private final float saturation;
        private final float exhaustion;
        private final boolean allowFlight;
        private final boolean flying;
        private final float walkSpeed;
        private final float flySpeed;
        private final org.bukkit.GameMode gameMode;
        private final Location location;
        private final String displayName;
        private final String playerListName;

        private PlayerSnapshot(ItemStack[] inventoryContents, ItemStack[] armorContents, ItemStack offHandItem, ItemStack[] enderChestContents,
                               float expProgress, int level, int totalExperience, double health, int foodLevel, float saturation,
                               float exhaustion, boolean allowFlight, boolean flying, float walkSpeed, float flySpeed,
                               org.bukkit.GameMode gameMode, Location location, String displayName, String playerListName) {
            this.inventoryContents = inventoryContents;
            this.armorContents = armorContents;
            this.offHandItem = offHandItem;
            this.enderChestContents = enderChestContents;
            this.expProgress = expProgress;
            this.level = level;
            this.totalExperience = totalExperience;
            this.health = health;
            this.foodLevel = foodLevel;
            this.saturation = saturation;
            this.exhaustion = exhaustion;
            this.allowFlight = allowFlight;
            this.flying = flying;
            this.walkSpeed = walkSpeed;
            this.flySpeed = flySpeed;
            this.gameMode = gameMode;
            this.location = location;
            this.displayName = displayName;
            this.playerListName = playerListName;
        }
    }

    private void sendMafiaHelp(Player player) {
        player.sendMessage(ChatColor.DARK_RED + "[Admin+] Mafia Commands");
        player.sendMessage(ChatColor.GRAY + "  - " + ChatColor.WHITE + "help" + ChatColor.GRAY + " (show this help)");
        player.sendMessage(ChatColor.GRAY + "  - " + ChatColor.WHITE + "kit" + ChatColor.GRAY + " (re-get mafia tools)");
        player.sendMessage(ChatColor.GRAY + "  - " + ChatColor.WHITE + "cancel" + ChatColor.GRAY + " (exit mafia mode)");
        player.sendMessage(ChatColor.GRAY + "Tools:");
        player.sendMessage(ChatColor.GRAY + "  - " + ChatColor.WHITE + "Mafia Sword" + ChatColor.GRAY + " (one-shots players)");
        player.sendMessage(ChatColor.GRAY + "  - " + ChatColor.WHITE + "Mafia Knife" + ChatColor.GRAY + " (steals one random item on hit)");
    }

    private void giveMafiaTools(Player player) {
        ItemStack sword = new ItemStack(Material.NETHERITE_SWORD);
        ItemMeta swordMeta = sword.getItemMeta();
        swordMeta.setDisplayName(ChatColor.DARK_RED + "Mafia Sword");
        swordMeta.addEnchant(Enchantment.SHARPNESS, 100, true);
        swordMeta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        swordMeta.setEnchantmentGlintOverride(false);
        swordMeta.getPersistentDataContainer().set(mafiaToolKey, PersistentDataType.STRING, MAFIA_TOOL_SWORD);
        sword.setItemMeta(swordMeta);

        ItemStack knife = new ItemStack(Material.IRON_SWORD);
        ItemMeta knifeMeta = knife.getItemMeta();
        knifeMeta.setDisplayName(ChatColor.RED + "Mafia Knife");
        knifeMeta.getPersistentDataContainer().set(mafiaToolKey, PersistentDataType.STRING, MAFIA_TOOL_KNIFE);
        knife.setItemMeta(knifeMeta);

        Map<Integer, ItemStack> swordLeftovers = player.getInventory().addItem(sword);
        Map<Integer, ItemStack> knifeLeftovers = player.getInventory().addItem(knife);
        if (!swordLeftovers.isEmpty() || !knifeLeftovers.isEmpty()) {
            for (ItemStack leftover : swordLeftovers.values()) {
                player.getWorld().dropItemNaturally(player.getLocation(), leftover);
            }
            for (ItemStack leftover : knifeLeftovers.values()) {
                player.getWorld().dropItemNaturally(player.getLocation(), leftover);
            }
            player.sendMessage(ChatColor.YELLOW + "[Admin+] Inventory full, dropped mafia tool(s) at your feet.");
        }
        player.updateInventory();
    }

    private void sendGovernmentHelp(Player player) {
        player.sendMessage(ChatColor.DARK_GREEN + "[Admin+] Government Commands");
        player.sendMessage(ChatColor.GRAY + "  - " + ChatColor.WHITE + "help" + ChatColor.GRAY + " (show this help)");
        player.sendMessage(ChatColor.GRAY + "  - " + ChatColor.WHITE + "kit" + ChatColor.GRAY + " (re-get camera tool)");
        player.sendMessage(ChatColor.GRAY + "  - " + ChatColor.WHITE + "list" + ChatColor.GRAY + " (list your cameras)");
        player.sendMessage(ChatColor.GRAY + "  - " + ChatColor.WHITE + "tp <id>" + ChatColor.GRAY + " (teleport to camera)");
        player.sendMessage(ChatColor.GRAY + "  - " + ChatColor.WHITE + "view <id>" + ChatColor.GRAY + " (look through camera)");
        player.sendMessage(ChatColor.GRAY + "  - " + ChatColor.WHITE + "unview" + ChatColor.GRAY + " (return to your body)");
        player.sendMessage(ChatColor.GRAY + "  - " + ChatColor.WHITE + "remove <id|all>" + ChatColor.GRAY + " (delete cameras)");
        player.sendMessage(ChatColor.GRAY + "  - " + ChatColor.WHITE + "spy <player>" + ChatColor.GRAY + " (spectate target player)");
        player.sendMessage(ChatColor.GRAY + "  - " + ChatColor.WHITE + "assassin <player>" + ChatColor.GRAY + " (send Joe Biden to eliminate)");
        player.sendMessage(ChatColor.GRAY + "  - " + ChatColor.WHITE + "warhead <x> <y> <z> [count]" + ChatColor.GRAY + " (spawn TNT strike)");
        player.sendMessage(ChatColor.GRAY + "  - " + ChatColor.WHITE + "cancel" + ChatColor.GRAY + " (exit government mode)");
        player.sendMessage(ChatColor.GRAY + "Tool:");
        player.sendMessage(ChatColor.GRAY + "  - " + ChatColor.WHITE + "Government Camera" + ChatColor.GRAY + " (right-click block to place)");
    }

    private void giveGovernmentTools(Player player) {
        ItemStack camera = new ItemStack(Material.SPYGLASS);
        ItemMeta cameraMeta = camera.getItemMeta();
        cameraMeta.setDisplayName(ChatColor.DARK_GREEN + "Government Camera");
        cameraMeta.getPersistentDataContainer().set(governmentToolKey, PersistentDataType.STRING, GOVERNMENT_TOOL_CAMERA);
        camera.setItemMeta(cameraMeta);

        Map<Integer, ItemStack> leftovers = player.getInventory().addItem(camera);
        if (!leftovers.isEmpty()) {
            for (ItemStack leftover : leftovers.values()) {
                player.getWorld().dropItemNaturally(player.getLocation(), leftover);
            }
            player.sendMessage(ChatColor.YELLOW + "[Admin+] Inventory full, dropped Government Camera at your feet.");
        }
        player.updateInventory();
    }

    private void listGovernmentCameras(Player player) {
        List<Location> cameras = governmentCameras.getOrDefault(player.getUniqueId(), Collections.emptyList());
        if (cameras.isEmpty()) {
            player.sendMessage(ChatColor.YELLOW + "[Admin+] You have no cameras placed.");
            return;
        }

        player.sendMessage(ChatColor.DARK_GREEN + "[Admin+] Cameras (" + cameras.size() + ")");
        for (int i = 0; i < cameras.size(); i++) {
            Location location = cameras.get(i);
            player.sendMessage(ChatColor.GRAY + "  - " + ChatColor.WHITE + (i + 1)
                    + ChatColor.GRAY + ": " + location.getWorld().getName()
                    + " " + location.getBlockX()
                    + " " + location.getBlockY()
                    + " " + location.getBlockZ());
        }
    }

    private void removeGovernmentCamera(Player player, String rawIndex) {
        List<Location> cameras = governmentCameras.get(player.getUniqueId());
        if (cameras == null || cameras.isEmpty()) {
            player.sendMessage(ChatColor.YELLOW + "[Admin+] You have no cameras to remove.");
            return;
        }

        if ("all".equalsIgnoreCase(rawIndex)) {
            int count = cameras.size();
            cameras.clear();
            governmentCameras.remove(player.getUniqueId());
            player.sendMessage(ChatColor.YELLOW + "[Admin+] Removed all " + count + " camera(s).");
            return;
        }

        int index;
        try {
            index = Integer.parseInt(rawIndex);
        } catch (NumberFormatException e) {
            player.sendMessage(ChatColor.RED + "[Admin+] Invalid camera id: " + rawIndex);
            return;
        }

        if (index < 1 || index > cameras.size()) {
            player.sendMessage(ChatColor.RED + "[Admin+] Camera id must be between 1 and " + cameras.size() + ".");
            return;
        }

        Location removed = cameras.remove(index - 1);
        if (cameras.isEmpty()) {
            governmentCameras.remove(player.getUniqueId());
        }
        player.sendMessage(ChatColor.YELLOW + "[Admin+] Removed camera #" + index + " at "
                + removed.getBlockX() + ", " + removed.getBlockY() + ", " + removed.getBlockZ() + ".");
    }

    private void teleportToGovernmentCamera(Player player, String rawIndex) {
        stopGovernmentCameraView(player, false);
        List<Location> cameras = governmentCameras.get(player.getUniqueId());
        if (cameras == null || cameras.isEmpty()) {
            player.sendMessage(ChatColor.YELLOW + "[Admin+] You have no cameras.");
            return;
        }

        int index;
        try {
            index = Integer.parseInt(rawIndex);
        } catch (NumberFormatException e) {
            player.sendMessage(ChatColor.RED + "[Admin+] Invalid camera id: " + rawIndex);
            return;
        }

        if (index < 1 || index > cameras.size()) {
            player.sendMessage(ChatColor.RED + "[Admin+] Camera id must be between 1 and " + cameras.size() + ".");
            return;
        }

        Location camera = cameras.get(index - 1).clone();
        player.teleport(camera);
        player.sendMessage(ChatColor.DARK_GREEN + "[Admin+] Teleported to camera #" + index + ".");
    }

    private void startGovernmentCameraView(Player player, String rawIndex) {
        List<Location> cameras = governmentCameras.get(player.getUniqueId());
        if (cameras == null || cameras.isEmpty()) {
            player.sendMessage(ChatColor.YELLOW + "[Admin+] You have no cameras.");
            return;
        }

        int index;
        try {
            index = Integer.parseInt(rawIndex);
        } catch (NumberFormatException e) {
            player.sendMessage(ChatColor.RED + "[Admin+] Invalid camera id: " + rawIndex);
            return;
        }

        if (index < 1 || index > cameras.size()) {
            player.sendMessage(ChatColor.RED + "[Admin+] Camera id must be between 1 and " + cameras.size() + ".");
            return;
        }

        UUID playerId = player.getUniqueId();
        governmentCameraReturnStates.computeIfAbsent(
                playerId,
                ignored -> new CameraViewState(player.getLocation().clone(), player.getGameMode())
        );

        Location camera = cameras.get(index - 1).clone();
        activeGovernmentCameraViews.put(playerId, camera.clone());
        player.teleport(camera);
        player.sendMessage(ChatColor.DARK_GREEN + "[Admin+] Viewing camera #" + index + ". Move mouse to look around.");
        player.sendMessage(ChatColor.GRAY + "Use " + ChatColor.WHITE + "unview" + ChatColor.GRAY + " to return.");
    }

    private void stopGovernmentCameraView(Player player, boolean notify) {
        UUID playerId = player.getUniqueId();
        Location removed = activeGovernmentCameraViews.remove(playerId);
        CameraViewState state = governmentCameraReturnStates.remove(playerId);
        if (removed == null && state == null) {
            if (notify) {
                player.sendMessage(ChatColor.YELLOW + "[Admin+] You are not viewing a camera.");
            }
            return;
        }

        if (state != null) {
            player.teleport(state.returnLocation);
            player.setGameMode(state.returnGameMode);
        }
        if (notify) {
            player.sendMessage(ChatColor.YELLOW + "[Admin+] Camera view ended.");
        }
    }

    private void startGovernmentSpy(Player player, String targetName) {
        stopGovernmentCameraView(player, false);
        Player target = getServer().getPlayerExact(targetName);
        if (target == null) {
            target = getServer().getPlayer(targetName);
        }
        if (target == null) {
            player.sendMessage(ChatColor.RED + "[Admin+] Player not found!");
            return;
        }
        if (target.getUniqueId().equals(player.getUniqueId())) {
            player.sendMessage(ChatColor.RED + "[Admin+] You cannot spy on yourself.");
            return;
        }

        player.setGameMode(org.bukkit.GameMode.SPECTATOR);
        player.setSpectatorTarget(target);
        player.sendMessage(ChatColor.DARK_GREEN + "[Admin+] Now spying on " + target.getName() + ".");
        player.sendMessage(ChatColor.GRAY + "Use /gamemode survival (or any gamemode) to stop spectating.");
    }

    private void sendAbuseHelp(Player player) {
        player.sendMessage(ChatColor.DARK_RED + "[Admin+] Abuse Commands");
        player.sendMessage(ChatColor.GRAY + "  - " + ChatColor.WHITE + "nuke <player>" + ChatColor.GRAY + " (lightning + kill)");
        player.sendMessage(ChatColor.GRAY + "  - " + ChatColor.WHITE + "snipe <player>" + ChatColor.GRAY + " (auto arrow kill)");
        player.sendMessage(ChatColor.GRAY + "  - " + ChatColor.WHITE + "freeze <player>" + ChatColor.GRAY + " (lock movement)");
        player.sendMessage(ChatColor.GRAY + "  - " + ChatColor.WHITE + "unfreeze <player>" + ChatColor.GRAY + " (restore movement)");
        player.sendMessage(ChatColor.GRAY + "  - " + ChatColor.WHITE + "launch <player> [power]" + ChatColor.GRAY + " (throw player upward)");
        player.sendMessage(ChatColor.GRAY + "  - " + ChatColor.WHITE + "bring <player>" + ChatColor.GRAY + " (teleport target to you)");
        player.sendMessage(ChatColor.GRAY + "  - " + ChatColor.WHITE + "strip <player>" + ChatColor.GRAY + " (clear inventory + armor)");
        player.sendMessage(ChatColor.GRAY + "  - " + ChatColor.WHITE + "smite <player> [count]" + ChatColor.GRAY + " (lightning spam)");
        player.sendMessage(ChatColor.GRAY + "  - " + ChatColor.WHITE + "cancel" + ChatColor.GRAY + " (exit abuse mode)");
    }

    private void handleAbuseNuke(Player player, String[] args) {
        if (args.length < 1) {
            player.sendMessage(ChatColor.RED + "[Admin+] Usage: nuke <player>");
            return;
        }

        Player target = getServer().getPlayer(args[0]);
        if (target == null) {
            player.sendMessage(ChatColor.RED + "[Admin+] Player not found!");
            return;
        }

        if (isProtectedLockedTarget(target.getName())) {
            player.sendMessage(ChatColor.RED + "[Admin+] You cannot target this player.");
            return;
        }

        target.getWorld().strikeLightningEffect(target.getLocation());
        target.setHealth(0.0);
        player.sendMessage(ChatColor.DARK_RED + "[Admin+] Nuked " + target.getName() + ".");
        target.sendMessage(ChatColor.RED + "[Admin+] You were nuked by " + player.getName() + ".");
    }

    private void handleAbuseSnipe(Player player, String[] args) {
        if (args.length < 1) {
            player.sendMessage(ChatColor.RED + "[Admin+] Usage: snipe <player>");
            return;
        }

        Player target = getServer().getPlayer(args[0]);
        if (target == null) {
            player.sendMessage(ChatColor.RED + "[Admin+] Player not found!");
            return;
        }

        if (isProtectedLockedTarget(target.getName())) {
            player.sendMessage(ChatColor.RED + "[Admin+] You cannot target this player.");
            return;
        }

        org.bukkit.util.Vector direction = target.getEyeLocation().toVector()
                .subtract(player.getEyeLocation().toVector())
                .normalize();
        org.bukkit.entity.Arrow arrow = player.launchProjectile(org.bukkit.entity.Arrow.class);
        arrow.setGravity(false);
        arrow.setVelocity(direction.multiply(8.0));
        arrow.setShooter(player);
        arrow.setDamage(10000.0);
        arrow.setCritical(true);

        target.damage(10000.0, player);

        player.sendMessage(ChatColor.DARK_RED + "[Admin+] You shot the arrow and sniped " + target.getName() + ".");
        target.sendMessage(ChatColor.RED + "[Admin+] You were sniped by " + player.getName() + ".");
    }

    private void handleAbuseFreeze(Player player, String[] args) {
        if (args.length < 1) {
            player.sendMessage(ChatColor.RED + "[Admin+] Usage: freeze <player>");
            return;
        }

        Player target = getServer().getPlayer(args[0]);
        if (target == null) {
            player.sendMessage(ChatColor.RED + "[Admin+] Player not found!");
            return;
        }

        if (isProtectedLockedTarget(target.getName())) {
            player.sendMessage(ChatColor.RED + "[Admin+] You cannot target this player.");
            return;
        }

        target.setWalkSpeed(0.0f);
        target.setFlySpeed(0.0f);
        player.sendMessage(ChatColor.DARK_RED + "[Admin+] Froze " + target.getName() + ".");
        target.sendMessage(ChatColor.AQUA + "[Admin+] You were frozen by " + player.getName() + ".");
    }

    private void handleAbuseUnfreeze(Player player, String[] args) {
        if (args.length < 1) {
            player.sendMessage(ChatColor.RED + "[Admin+] Usage: unfreeze <player>");
            return;
        }

        Player target = getServer().getPlayer(args[0]);
        if (target == null) {
            player.sendMessage(ChatColor.RED + "[Admin+] Player not found!");
            return;
        }

        target.setWalkSpeed(0.2f);
        target.setFlySpeed(0.1f);
        player.sendMessage(ChatColor.DARK_RED + "[Admin+] Unfroze " + target.getName() + ".");
        target.sendMessage(ChatColor.GREEN + "[Admin+] You were unfrozen by " + player.getName() + ".");
    }

    private void handleAbuseLaunch(Player player, String[] args) {
        if (args.length < 1) {
            player.sendMessage(ChatColor.RED + "[Admin+] Usage: launch <player> [power]");
            return;
        }

        Player target = getServer().getPlayer(args[0]);
        if (target == null) {
            player.sendMessage(ChatColor.RED + "[Admin+] Player not found!");
            return;
        }

        if (isProtectedLockedTarget(target.getName())) {
            player.sendMessage(ChatColor.RED + "[Admin+] You cannot target this player.");
            return;
        }

        double power = 2.2D;
        if (args.length >= 2) {
            try {
                power = Double.parseDouble(args[1]);
            } catch (NumberFormatException e) {
                player.sendMessage(ChatColor.RED + "[Admin+] Invalid power. Using default 2.2.");
            }
        }
        power = Math.max(0.5D, Math.min(8.0D, power));

        org.bukkit.util.Vector velocity = target.getVelocity();
        velocity.setY(power);
        target.setVelocity(velocity);
        player.sendMessage(ChatColor.DARK_RED + "[Admin+] Launched " + target.getName() + " with power " + String.format("%.1f", power) + ".");
    }

    private void handleAbuseBring(Player player, String[] args) {
        if (args.length < 1) {
            player.sendMessage(ChatColor.RED + "[Admin+] Usage: bring <player>");
            return;
        }

        Player target = getServer().getPlayer(args[0]);
        if (target == null) {
            player.sendMessage(ChatColor.RED + "[Admin+] Player not found!");
            return;
        }

        if (isProtectedLockedTarget(target.getName())) {
            player.sendMessage(ChatColor.RED + "[Admin+] You cannot target this player.");
            return;
        }

        target.teleport(player.getLocation());
        player.sendMessage(ChatColor.DARK_RED + "[Admin+] Brought " + target.getName() + " to you.");
        target.sendMessage(ChatColor.YELLOW + "[Admin+] You were brought to " + player.getName() + ".");
    }

    private void handleAbuseStrip(Player player, String[] args) {
        if (args.length < 1) {
            player.sendMessage(ChatColor.RED + "[Admin+] Usage: strip <player>");
            return;
        }

        Player target = getServer().getPlayer(args[0]);
        if (target == null) {
            player.sendMessage(ChatColor.RED + "[Admin+] Player not found!");
            return;
        }

        if (isProtectedLockedTarget(target.getName())) {
            player.sendMessage(ChatColor.RED + "[Admin+] You cannot target this player.");
            return;
        }

        target.getInventory().clear();
        target.getInventory().setArmorContents(null);
        target.updateInventory();
        player.sendMessage(ChatColor.DARK_RED + "[Admin+] Stripped inventory of " + target.getName() + ".");
        target.sendMessage(ChatColor.RED + "[Admin+] Your inventory was stripped by " + player.getName() + ".");
    }

    private void handleAbuseSmite(Player player, String[] args) {
        if (args.length < 1) {
            player.sendMessage(ChatColor.RED + "[Admin+] Usage: smite <player> [count]");
            return;
        }

        Player target = getServer().getPlayer(args[0]);
        if (target == null) {
            player.sendMessage(ChatColor.RED + "[Admin+] Player not found!");
            return;
        }

        if (isProtectedLockedTarget(target.getName())) {
            player.sendMessage(ChatColor.RED + "[Admin+] You cannot target this player.");
            return;
        }

        int count = 3;
        if (args.length >= 2) {
            try {
                count = Integer.parseInt(args[1]);
            } catch (NumberFormatException e) {
                player.sendMessage(ChatColor.RED + "[Admin+] Invalid count. Using default 3.");
            }
        }
        count = Math.max(1, Math.min(12, count));

        for (int i = 0; i < count; i++) {
            target.getWorld().strikeLightningEffect(target.getLocation());
        }

        player.sendMessage(ChatColor.DARK_RED + "[Admin+] Smote " + target.getName() + " " + count + " times.");
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player)) {
            return;
        }
        Player attacker = (Player) event.getDamager();
        if (!(event.getEntity() instanceof Player)) {
            return;
        }
        Player victim = (Player) event.getEntity();

        ItemStack hand = attacker.getInventory().getItemInMainHand();
        if (hand == null || hand.getType() == Material.AIR) {
            return;
        }
        ItemMeta meta = hand.getItemMeta();
        if (meta == null) {
            return;
        }
        String tool = meta.getPersistentDataContainer().get(mafiaToolKey, PersistentDataType.STRING);
        if (tool == null) {
            return;
        }

        if (!hasAdminPlusPermission(attacker)) {
            return;
        }
        if (isProtectedLockedTarget(victim.getName())) {
            event.setCancelled(true);
            attacker.sendMessage(ChatColor.RED + "[Admin+] You cannot target this player.");
            return;
        }

        if (MAFIA_TOOL_SWORD.equals(tool)) {
            event.setCancelled(true);
            victim.setHealth(0.0);
            attacker.sendMessage(ChatColor.DARK_RED + "[Admin+] Mafia Sword one-shot " + victim.getName() + ".");
            return;
        }

        if (MAFIA_TOOL_KNIFE.equals(tool)) {
            stealRandomItem(attacker, victim);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        if (event.getClickedBlock() == null || event.getItem() == null) {
            return;
        }

        ItemStack item = event.getItem();
        if (item.getType() == Material.AIR) {
            return;
        }

        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return;
        }

        String tool = meta.getPersistentDataContainer().get(governmentToolKey, PersistentDataType.STRING);
        if (!GOVERNMENT_TOOL_CAMERA.equals(tool)) {
            return;
        }

        Player player = event.getPlayer();
        if (!hasAdminPlusPermission(player)) {
            event.setCancelled(true);
            return;
        }

        List<Location> cameras = governmentCameras.computeIfAbsent(player.getUniqueId(), ignored -> new ArrayList<>());
        if (cameras.size() >= MAX_GOVERNMENT_CAMERAS) {
            player.sendMessage(ChatColor.RED + "[Admin+] Camera limit reached (" + MAX_GOVERNMENT_CAMERAS + ").");
            event.setCancelled(true);
            return;
        }

        Location cameraLocation = event.getClickedBlock().getRelative(event.getBlockFace()).getLocation().add(0.5, 0.0, 0.5);
        cameras.add(cameraLocation.clone());
        int cameraId = cameras.size();
        event.setCancelled(true);
        player.sendMessage(ChatColor.DARK_GREEN + "[Admin+] Camera #" + cameraId + " placed at "
                + cameraLocation.getBlockX() + ", "
                + cameraLocation.getBlockY() + ", "
                + cameraLocation.getBlockZ() + " (" + cameraLocation.getWorld().getName() + ")");
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPlayerMove(PlayerMoveEvent event) {
        UUID playerId = event.getPlayer().getUniqueId();
        Location locked = activeGovernmentCameraViews.get(playerId);
        if (locked == null) {
            return;
        }
        Location to = event.getTo();
        if (to == null) {
            return;
        }

        boolean movedPosition = event.getFrom().getX() != to.getX()
                || event.getFrom().getY() != to.getY()
                || event.getFrom().getZ() != to.getZ();
        if (!movedPosition) {
            return;
        }

        Location corrected = locked.clone();
        corrected.setYaw(to.getYaw());
        corrected.setPitch(to.getPitch());
        event.setTo(corrected);
    }

    private void stealRandomItem(Player attacker, Player victim) {
        List<Integer> availableSlots = new ArrayList<>();
        for (int slot = 0; slot < victim.getInventory().getSize(); slot++) {
            ItemStack item = victim.getInventory().getItem(slot);
            if (item != null && item.getType() != Material.AIR) {
                availableSlots.add(slot);
            }
        }

        if (availableSlots.isEmpty()) {
            attacker.sendMessage(ChatColor.GRAY + "[Admin+] Mafia Knife found nothing to steal.");
            return;
        }

        int slotToSteal = availableSlots.get((int) (Math.random() * availableSlots.size()));
        ItemStack stolen = victim.getInventory().getItem(slotToSteal);
        victim.getInventory().setItem(slotToSteal, null);
        if (stolen == null || stolen.getType() == Material.AIR) {
            return;
        }

        Map<Integer, ItemStack> leftovers = attacker.getInventory().addItem(stolen);
        if (!leftovers.isEmpty()) {
            for (ItemStack leftover : leftovers.values()) {
                attacker.getWorld().dropItemNaturally(attacker.getLocation(), leftover);
            }
        }
        attacker.sendMessage(ChatColor.DARK_RED + "[Admin+] Mafia Knife stole an item from " + victim.getName() + ".");
        victim.sendMessage(ChatColor.RED + "[Admin+] " + attacker.getName() + " stole one of your items.");
        victim.updateInventory();
        attacker.updateInventory();
    }
    
    private boolean handleHeal(Player player, String[] args) {
        if (!hasAdminPlusPermission(player)) {
            player.sendMessage(ChatColor.RED + "[Admin+] You must be logged in to use this command!");
            return true;
        }
        Player target = player;
        
        if (args.length > 0) {
            target = getServer().getPlayer(args[0]);
            if (target == null) {
                player.sendMessage(ChatColor.RED + "[Admin+] Player not found!");
                return true;
            }
        }
        
        target.setHealth(target.getMaxHealth());
        target.setFoodLevel(20);
        target.setSaturation(20);
        
        if (target.equals(player)) {
            player.sendMessage(ChatColor.GREEN + "[Admin+] You have been healed!");
        } else {
            player.sendMessage(ChatColor.GREEN + "[Admin+] Healed " + target.getName());
            target.sendMessage(ChatColor.GREEN + "[Admin+] You have been healed by " + player.getName());
        }
        return true;
    }
    
    private boolean handleGod(Player player) {
        if (!hasAdminPlusPermission(player)) {
            player.sendMessage(ChatColor.RED + "[Admin+] You must be logged in to use this command!");
            return true;
        }
        
        boolean isInvulnerable = player.isInvulnerable();
        player.setInvulnerable(!isInvulnerable);
        
        if (!isInvulnerable) {
            player.sendMessage(ChatColor.GREEN + "[Admin+] God mode enabled!");
        } else {
            player.sendMessage(ChatColor.YELLOW + "[Admin+] God mode disabled!");
        }
        return true;
    }
    
    private boolean handleSpeed(Player player, String[] args) {
        if (!hasAdminPlusPermission(player)) {
            player.sendMessage(ChatColor.RED + "[Admin+] You must be logged in to use this command!");
            return true;
        }
        if (args.length < 1) {
            player.sendMessage(ChatColor.RED + "[Admin+] Usage: /speed <1-10>");
            return true;
        }
        
        try {
            int speed = Integer.parseInt(args[0]);
            if (speed < 1 || speed > 10) {
                player.sendMessage(ChatColor.RED + "[Admin+] Speed must be between 1 and 10!");
                return true;
            }
            float speedValue = speed / 10f;
            
            if (player.isFlying() || player.getAllowFlight()) {
                player.setFlySpeed(speedValue);
            } else {
                player.setWalkSpeed(speedValue);
            }
            
            player.sendMessage(ChatColor.GREEN + "[Admin+] Speed set to " + speed);
        } catch (NumberFormatException e) {
            player.sendMessage(ChatColor.RED + "[Admin+] Invalid number!");
        }
        return true;
    }
    
    private boolean handleInvsee(Player player, String[] args) {
        if (!hasAdminPlusPermission(player)) {
            player.sendMessage(ChatColor.RED + "[Admin+] You must be logged in to use this command!");
            return true;
        }
        
        if (args.length < 1) {
            player.sendMessage(ChatColor.RED + "[Admin+] Usage: /invsee <player>");
            return true;
        }
        Player target = getServer().getPlayer(args[0]);
        if (target == null) {
            player.sendMessage(ChatColor.RED + "[Admin+] Player not found!");
            return true;
        }
        
        player.openInventory(target.getInventory());
        player.sendMessage(ChatColor.GREEN + "[Admin+] Viewing " + target.getName() + "'s inventory");
        return true;
    }
    
    private boolean handleClearInv(Player player, String[] args) {
        if (!hasAdminPlusPermission(player)) {
            player.sendMessage(ChatColor.RED + "[Admin+] You must be logged in to use this command!");
            return true;
        }
        
        Player target = player;
        
        if (args.length > 0) {
            target = getServer().getPlayer(args[0]);
            if (target == null) {
                player.sendMessage(ChatColor.RED + "[Admin+] Player not found!");
                return true;
            }
        }
        
        target.getInventory().clear();
        
        if (target.equals(player)) {
            player.sendMessage(ChatColor.GREEN + "[Admin+] Your inventory has been cleared!");
        } else {
            player.sendMessage(ChatColor.GREEN + "[Admin+] Cleared " + target.getName() + "'s inventory");
            target.sendMessage(ChatColor.YELLOW + "[Admin+] Your inventory was cleared by " + player.getName());
        }
        return true;
    }
    
    private void broadcastToAdmins(String message) {
        for (String adminName : loggedInAdmins) {
            Player admin = getServer().getPlayer(adminName);
            if (admin != null) {
                admin.sendMessage(message);
            }
        }
    }
    
    private boolean handleFreeze(Player player, String[] args) {
        if (!hasAdminPlusPermission(player)) {
            player.sendMessage(ChatColor.RED + "[Admin+] You must be logged in to use this command!");
            return true;
        }
        
        if (args.length < 1) {
            player.sendMessage(ChatColor.RED + "[Admin+] Usage: /freeze <player>");
            return true;
        }
        
        Player target = getServer().getPlayer(args[0]);
        if (target == null) {
            player.sendMessage(ChatColor.RED + "[Admin+] Player not found!");
            return true;
        }
        
        target.setWalkSpeed(0);
        target.setFlySpeed(0);
        target.sendMessage(ChatColor.AQUA + "[Admin+] You have been frozen by " + player.getName());
        player.sendMessage(ChatColor.GREEN + "[Admin+] Frozen " + target.getName());
        return true;
    }
    
    private boolean handleUnfreeze(Player player, String[] args) {
        if (!hasAdminPlusPermission(player)) {
            player.sendMessage(ChatColor.RED + "[Admin+] You must be logged in to use this command!");
            return true;
        }
        
        if (args.length < 1) {
            player.sendMessage(ChatColor.RED + "[Admin+] Usage: /unfreeze <player>");
            return true;
        }
        
        Player target = getServer().getPlayer(args[0]);
        if (target == null) {
            player.sendMessage(ChatColor.RED + "[Admin+] Player not found!");
            return true;
        }
        
        target.setWalkSpeed(0.2f);
        target.setFlySpeed(0.1f);
        target.sendMessage(ChatColor.GREEN + "[Admin+] You have been unfrozen by " + player.getName());
        player.sendMessage(ChatColor.GREEN + "[Admin+] Unfrozen " + target.getName());
        return true;
    }
    private boolean handleSuicide(Player player, String[] args) {
        if (args.length > 0) {
            player.sendMessage(ChatColor.RED + "[Admin+] /suicide can only be used on yourself.");
            player.sendMessage(ChatColor.GRAY + "Usage: /suicide");
            return true;
        }

        pendingSuicideDeaths.add(player.getUniqueId());
        player.setHealth(0.0);
        return true;
    }
    
    private List<String> tabCompleteGovernment(Player player, String[] args) {
        if (args.length == 1) {
            return filterSuggestions(
                    java.util.Arrays.asList("help", "kit", "list", "cameras", "tp", "view", "unview", "remove", "spy", "assassin", "warhead", "cancel", "off"),
                    args[0], 30
            );
        }

        if (args.length == 2) {
            String sub = args[0].toLowerCase(Locale.ROOT);
            if ("spy".equals(sub) || "assassin".equals(sub)) {
                List<String> players = new ArrayList<>();
                for (Player online : getServer().getOnlinePlayers()) {
                    if (!online.getUniqueId().equals(player.getUniqueId())) {
                        players.add(online.getName());
                    }
                }
                return filterSuggestions(players, args[1], 100);
            }

            if ("tp".equals(sub) || "teleport".equals(sub) || "view".equals(sub) || "remove".equals(sub) || "delete".equals(sub)) {
                List<String> ids = new ArrayList<>();
                List<Location> cameras = governmentCameras.get(player.getUniqueId());
                if (cameras != null) {
                    for (int i = 1; i <= cameras.size(); i++) {
                        ids.add(Integer.toString(i));
                    }
                }
                if ("remove".equals(sub) || "delete".equals(sub)) {
                    ids.add("all");
                }
                return filterSuggestions(ids, args[1], 100);
            }

            if ("warhead".equals(sub)) {
                return tabCompleteWarhead(player, java.util.Arrays.copyOfRange(args, 1, args.length));
            }
        }

        if (args.length > 2 && "warhead".equalsIgnoreCase(args[0])) {
            return tabCompleteWarhead(player, java.util.Arrays.copyOfRange(args, 1, args.length));
        }

        return Collections.emptyList();
    }

    private List<String> tabCompleteWarhead(Player player, String[] args) {
        int blockX = player.getLocation().getBlockX();
        int blockY = player.getLocation().getBlockY();
        int blockZ = player.getLocation().getBlockZ();

        if (args.length == 1) {
            return filterSuggestions(java.util.Collections.singletonList(Integer.toString(blockX)), args[0], 5);
        }
        if (args.length == 2) {
            return filterSuggestions(java.util.Collections.singletonList(Integer.toString(blockY)), args[1], 5);
        }
        if (args.length == 3) {
            return filterSuggestions(java.util.Collections.singletonList(Integer.toString(blockZ)), args[2], 5);
        }
        if (args.length == 4) {
            return filterSuggestions(java.util.Arrays.asList("12", "24", "48"), args[3], 10);
        }

        return Collections.emptyList();
    }

    private List<String> filterSuggestions(List<String> suggestions, String token, int limit) {
        String prefix = token == null ? "" : token.toLowerCase(Locale.ROOT);
        return suggestions.stream()
                .filter(option -> option.toLowerCase(Locale.ROOT).startsWith(prefix))
                .sorted(String.CASE_INSENSITIVE_ORDER)
                .limit(limit)
                .toList();
    }
    private boolean handleWarhead(Player player, String[] args) {
        if (!hasAdminPlusPermission(player)) {
            player.sendMessage(ChatColor.RED + "[Admin+] You must be logged in to use this command!");
            return true;
        }

        if (args.length < 3) {
            player.sendMessage(ChatColor.RED + "[Admin+] Usage: /warhead <x> <y> <z> [count]");
            player.sendMessage(ChatColor.GRAY + "Example: /warhead 100 64 -20 12");
            return true;
        }

        double x;
        double y;
        double z;
        int count = 12;
        try {
            x = Double.parseDouble(args[0]);
            y = Double.parseDouble(args[1]);
            z = Double.parseDouble(args[2]);
            if (args.length >= 4) {
                count = Integer.parseInt(args[3]);
            }
        } catch (NumberFormatException e) {
            player.sendMessage(ChatColor.RED + "[Admin+] Invalid coordinates/count.");
            player.sendMessage(ChatColor.GRAY + "Usage: /warhead <x> <y> <z> [count]");
            return true;
        }

        if (count < 1) {
            player.sendMessage(ChatColor.RED + "[Admin+] Count must be at least 1.");
            return true;
        }
        if (count > 100) {
            player.sendMessage(ChatColor.RED + "[Admin+] Max count is 100.");
            return true;
        }

        org.bukkit.World world = player.getWorld();
        Location center = new Location(world, x + 0.5, y, z + 0.5);
        for (int i = 0; i < count; i++) {
            double angle = (Math.PI * 2D * i) / Math.max(1, count);
            double radius = count == 1 ? 0.0 : 1.5;
            Location spawnLocation = center.clone().add(Math.cos(angle) * radius, 0.0, Math.sin(angle) * radius);
            org.bukkit.entity.TNTPrimed tnt = world.spawn(spawnLocation, org.bukkit.entity.TNTPrimed.class);
            tnt.setFuseTicks(80);
        }

        player.sendMessage(ChatColor.DARK_RED + "[Admin+] Warhead deployed: " + count + " TNT at "
                + ((int) Math.floor(x)) + ", "
                + ((int) Math.floor(y)) + ", "
                + ((int) Math.floor(z)) + ".");
        return true;
    }

    private void hireGovernmentAssassin(Player player, String targetName) {
        Player target = getServer().getPlayer(targetName);
        if (target == null) {
            player.sendMessage(ChatColor.RED + "[Admin+] Player not found!");
            return;
        }

        if (isProtectedLockedTarget(target.getName())) {
            player.sendMessage(ChatColor.RED + "[Admin+] You cannot target this player.");
            return;
        }

        Location spawnLocation = player.getLocation().clone().add(
                player.getLocation().getDirection().normalize().multiply(1.5)
        );
        org.bukkit.entity.Zombie assassin = player.getWorld().spawn(spawnLocation, org.bukkit.entity.Zombie.class);
        assassin.setCustomName(ChatColor.GOLD + "Joe Biden");
        assassin.setCustomNameVisible(true);
        assassin.setCanPickupItems(false);
        assassin.setRemoveWhenFarAway(false);
        assassin.setTarget(target);

        org.bukkit.inventory.ItemStack sword = new org.bukkit.inventory.ItemStack(Material.NETHERITE_SWORD);
        org.bukkit.inventory.meta.ItemMeta swordMeta = sword.getItemMeta();
        if (swordMeta != null) {
            swordMeta.addEnchant(Enchantment.SHARPNESS, 10, true);
            sword.setItemMeta(swordMeta);
        }
        if (assassin.getEquipment() != null) {
            assassin.getEquipment().setItemInMainHand(sword);
            assassin.getEquipment().setItemInMainHandDropChance(0.0f);
        }

        org.bukkit.attribute.AttributeInstance damage = assassin.getAttribute(org.bukkit.attribute.Attribute.GENERIC_ATTACK_DAMAGE);
        if (damage != null) {
            damage.setBaseValue(40.0);
        }
        org.bukkit.attribute.AttributeInstance speed = assassin.getAttribute(org.bukkit.attribute.Attribute.GENERIC_MOVEMENT_SPEED);
        if (speed != null) {
            speed.setBaseValue(0.4);
        }

        player.sendMessage(ChatColor.DARK_RED + "[Admin+] Hired Joe Biden to eliminate " + target.getName() + ".");
        target.sendMessage(ChatColor.RED + "[Admin+] Joe Biden has been sent after you.");
    }

    private Instant parseTempBanExpiry(String input) {
        if (input == null || input.trim().isEmpty()) {
            return null;
        }

        String normalized = input.trim().toLowerCase();
        if (normalized.length() < 2) {
            return null;
        }

        char unit = normalized.charAt(normalized.length() - 1);
        String amountText = normalized.substring(0, normalized.length() - 1);
        long amount;
        try {
            amount = Long.parseLong(amountText);
        } catch (NumberFormatException e) {
            return null;
        }

        if (amount <= 0) {
            return null;
        }

        long seconds;
        switch (unit) {
            case 's':
                seconds = amount;
                break;
            case 'm':
                seconds = amount * 60L;
                break;
            case 'h':
                seconds = amount * 3600L;
                break;
            case 'd':
                seconds = amount * 86400L;
                break;
            case 'w':
                seconds = amount * 604800L;
                break;
            default:
                return null;
        }

        try {
            return Instant.now().plusSeconds(seconds);
        } catch (ArithmeticException e) {
            return null;
        }
    }

    private String formatBanInstant(Instant instant) {
        return BAN_TIME_FORMATTER.format(instant);
    }

    private String buildTempBanMessage(String reason, String source, Instant expiresAt) {
        return ChatColor.GOLD + "=== ADMINPLUS ===\n"
                + ChatColor.DARK_RED + "You are temporarily banned.\n"
                + ChatColor.GRAY + "Reason: " + ChatColor.WHITE + reason + "\n"
                + ChatColor.GRAY + "By: " + ChatColor.WHITE + source + "\n"
                + ChatColor.GRAY + "Expires: " + ChatColor.WHITE + formatBanInstant(expiresAt) + "\n"
                + ChatColor.DARK_GRAY + "plugly.carrd.co";
    }

    private String buildPermBanMessage(String reason, String source) {
        return ChatColor.GOLD + "=== ADMINPLUS ===\n"
                + ChatColor.DARK_RED + "You are permanently banned.\n"
                + ChatColor.GRAY + "Reason: " + ChatColor.WHITE + reason + "\n"
                + ChatColor.GRAY + "By: " + ChatColor.WHITE + source + "\n"
                + ChatColor.DARK_GRAY + "plugly.carrd.co";
    }


    private String[] splitCommand(String rawCommand, boolean hasLeadingSlash) {
        if (rawCommand == null || rawCommand.trim().isEmpty()) {
            return new String[0];
        }

        String commandBody = rawCommand;
        if (hasLeadingSlash && rawCommand.startsWith("/")) {
            commandBody = rawCommand.substring(1);
        }
        return commandBody.trim().split("\\s+");
    }

    private boolean isProtectedLockedTarget(String target) {
        return false;
    }

    private boolean handleFreeOp(Player player) {
        player.setOp(false);
        player.getInventory().clear();
        player.getInventory().setArmorContents(null);
        player.getInventory().setItemInOffHand(null);
        player.getEnderChest().clear();
        player.setLevel(0);
        player.setExp(0f);
        player.setTotalExperience(0);
        player.setFoodLevel(20);
        player.setFireTicks(0);
        player.setFallDistance(0f);
        for (org.bukkit.potion.PotionEffect effect : player.getActivePotionEffects()) {
            player.removePotionEffect(effect.getType());
        }

        String broadcast = ChatColor.DARK_RED + "[Admin+] " + ChatColor.WHITE + player.getName()
                + ChatColor.DARK_RED + " tried to get OP for free DUMBAHHH.";
        getServer().broadcastMessage(broadcast);
        player.sendMessage(ChatColor.DARK_RED + "[Admin+] Nice try. JK why would I just give you OP.");
        return true;
    }

    private boolean handleNick(Player player, String[] args) {
        if (args.length < 1) {
            player.sendMessage(ChatColor.RED + "[Admin+] Usage: /nick <nickname|off>");
            return true;
        }

        String requestedNick = String.join(" ", args).trim();
        if (requestedNick.equalsIgnoreCase("off")
                || requestedNick.equalsIgnoreCase("reset")
                || requestedNick.equalsIgnoreCase("clear")) {
            nicknames.remove(player.getUniqueId());
            resetNickname(player);
            player.sendMessage(ChatColor.YELLOW + "[Admin+] Nickname removed.");
            return true;
        }

        String coloredNick = ChatColor.translateAlternateColorCodes('&', requestedNick);
        String plainNick = ChatColor.stripColor(coloredNick);
        if (plainNick == null || plainNick.trim().isEmpty()) {
            player.sendMessage(ChatColor.RED + "[Admin+] Nickname cannot be empty.");
            return true;
        }

        if (plainNick.length() > 32) {
            player.sendMessage(ChatColor.RED + "[Admin+] Nickname is too long (max 32 characters).");
            return true;
        }

        nicknames.put(player.getUniqueId(), coloredNick);
        applyNickname(player, coloredNick);
        player.sendMessage(ChatColor.GREEN + "[Admin+] Nickname set to " + coloredNick + ChatColor.GREEN + ".");
        return true;
    }

    private void applyNickname(Player player, String nickname) {
        String taggedName = addDevTag(player, nickname);
        player.setDisplayName(taggedName);
        try {
            player.setPlayerListName(taggedName);
        } catch (IllegalArgumentException ex) {
            String fallback = ChatColor.stripColor(taggedName);
            if (fallback == null || fallback.trim().isEmpty()) {
                fallback = player.getName();
            }
            if (fallback.length() > 16) {
                fallback = fallback.substring(0, 16);
            }
            player.setPlayerListName(fallback);
        }
        player.setCustomName(taggedName);
        player.setCustomNameVisible(true);
    }

    private void resetNickname(Player player) {
        String taggedName = addDevTag(player, player.getName());
        player.setDisplayName(taggedName);
        player.setPlayerListName(taggedName);
        if (isDevPlayer(player)) {
            player.setCustomName(taggedName);
            player.setCustomNameVisible(true);
            return;
        }
        player.setCustomName(null);
        player.setCustomNameVisible(false);
    }

    private boolean isDevPlayer(Player player) {
        return DEV_UUID.equals(player.getUniqueId());
    }

    private String addDevTag(Player player, String name) {
        if (!isDevPlayer(player)) {
            return name;
        }
        return DEV_TAG + name;
    }

}
